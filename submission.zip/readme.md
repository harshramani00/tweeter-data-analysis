## Harsh Anilkumar Ramani

## Overview
Due to limited resources on my local machine (4 cores, 8GB RAM), I used a smaller subset of the dataset for initial testing and preprocessing. As part of preprocessing, I combined multiple NDJSON part files into a single consolidated JSON file to simplify execution and avoid overhead during parsing.

Once preprocessing was completed locally, I uploaded the full 5 million record dataset to Google Cloud Storage and performed all required tasks using Hadoop and Spark on GCP Dataproc.

## Execution Summary
- **Preprocessing**: Done locally using Python to combine files and validate structure.
- **Cloud Processing**: Full dataset processed on GCP using:
  - Hadoop Streaming
  - PySpark
- **Storage**: Input/output managed via GCS bucket: `gs://cse532-a4-bucket`.

## Performance Measurement
Execution times for all approaches (local, Hadoop, Spark) were recorded using job logs and counters. Final timings are summarized in `performance.txt`.
